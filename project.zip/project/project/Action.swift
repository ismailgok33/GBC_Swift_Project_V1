enum Action{
    case ENEMY_IS_ATTAKING
    case HERO_IS_ATTAKING
    case HERO_IS_SNEAKING
    case HERO_IS_RUNNING_AWAY
}
