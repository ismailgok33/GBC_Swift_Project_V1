class GameCharacter:CustomStringConvertible{
    let name:String
    var maxHealthPoint:Float
    let type: GameCharacterType
    
    init(_ name:String, _ maxHealthPoint:Float, _ type:GameCharacterType){
        self.name = name
        self.maxHealthPoint = maxHealthPoint
        self.type = type
    }
    
    func takeDamage(dmPoint:Int){
        self.maxHealthPoint = self.maxHealthPoint - Float(dmPoint)
    }
    
    func attack() -> Int{
        return 0;
    }
}

extension GameCharacter{
    var description: String{
        get{
            return "The name of the \(type) is \(name) and max health point of \(name) is \(maxHealthPoint)."
        }
    }
}
