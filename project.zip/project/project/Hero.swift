class Hero:GameCharacter{
    let weaponStrength:Float
    
    init(_ name:String, _ maxHealthPoint:Float, _ type:GameCharacterType, _ weaponStrength:Float){
        self.weaponStrength = weaponStrength
        super.init(name, maxHealthPoint, type)
    }
    
    func sneak(){
        print("\(name) successfully sneak past the obstacles.")
    }
    
}
