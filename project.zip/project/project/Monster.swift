class Monster:GameCharacter{
    let attackPower:Float
    
    init(_ name:String, _ maxHealthPoint:Float, _ type:GameCharacterType, _ attackPower:Float){
        self.attackPower = attackPower
        super.init(name, maxHealthPoint, type)
    }
}
