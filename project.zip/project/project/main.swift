let hero = Hero("HUGIE", 100, GameCharacterType.HERO,30)
let monster = Monster("NEMEAN LION", 150, GameCharacterType.MONSTER, 20)

print(hero)
print(monster)

let fight = Fight(hero, monster)

fight.fightBegin()
